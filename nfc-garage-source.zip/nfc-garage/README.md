# NFC Garage

A text-free, mobile-friendly 3D studio for a physical two-car display.

## Open

`npm install` then `npm run dev`. Open the printed local URL.

- `/rx7` — red Mazda RX-7 FD, with pop-up headlights.
- `/gt500` — blue Shelby GT500 with white stripes.

Drag to orbit. Scroll or pinch to zoom; two fingers pan. The six controls open the doors, switch the lights, open the bonnet, rotate the view, change the lighting, and reset everything. The official Mazda and Ford logos select the car. Accessible names and keyboard focus are provided without visible text.

Click or tap either door to open that door independently; tap it again to close it. Tap the bonnet or headlight surfaces to toggle them. The controls stay in sync, and dragging across a panel only rotates the camera. The wind icon at the upper right reveals animated streamlines and rear vortices, with paths adjusted for open panels. Airflow is an illustrative wind-tunnel effect, not a CFD simulation. It remains static when reduced motion is requested.

Airflow also spins all four wheels and starts the selected engine sound. Turning it off stops both. The speaker control independently plays the engine at idle, or mutes it while airflow and the wheels continue. The engine ramps up in airflow mode. Switching cars, resetting, or hiding the tab stops audio. Sound only starts after a user gesture; the small bar below the speaker reflects measured audio output.

Audio is original procedural synthesis: two-rotor exhaust pulses and turbo texture for the RX-7, with uneven V8 exhaust pulses and supercharger whine for the Shelby. These are illustrative engine voices, not vehicle recordings. Logo sources are documented in `public/brands/SOURCES.txt`.

## NFC

Write the hosted site's `/rx7` URL to one tag and `/gt500` to the other as standard NFC URL records. A phone opens the selected scene in its browser; the site does not request NFC hardware access. The hosted Site is public, as requested, so NFC visitors do not need to sign in. Sharing can be changed in Sites if desired. Physical NFC scans have not been hardware-tested.

## Build

`npm run build` creates `dist/`, including real route entry files for static hosting. `npm run preview` serves the production build locally. No backend, account database, API keys, or analytics are needed by the app.

## Models and adaptation

Models were downloaded from the creators' Sketchfab listings. Full attribution, source links, and CC BY-NC-SA 4.0 terms are in `public/attribution.txt`, accessible through the small information icon.

The original downloads are retained locally in `assets/source/` and excluded from source control. `npm run prepare-models` reproduces optimized GLBs from `rx7.glb` and `gt500.glb` there. The pipeline bakes transforms, separates components, creates mechanical pivots after quantization, recolors the RX-7, simplifies geometry, and applies Meshopt compression. The RX-7's original continuous shell is split into moving panels; its added engine-bay shapes are illustrative. These are interactive visualizations, not mechanical CAD replicas.

The app uses React, Three.js, React Three Fiber, Drei, and Vite. Only the selected car loads. Rendering pauses when the tab is hidden. Automatic motion starts only on request, and mechanical transitions respect reduced-motion preferences.

## GitHub Pages

`npm run build:pages` builds for `https://avrgc0der.github.io/nfc-garage/`. Copy the contents of `dist/` into `docs/` and commit the changes. GitHub Pages is configured to publish `main` → `/docs`. The NFC URLs are `/nfc-garage/rx7/` and `/nfc-garage/gt500/`. `npm run build` still supports hosting at a domain root.
