import React, { Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { Maximize, Minimize, RotateCcw, Orbit, Sun, Moon, Info, RefreshCw, TriangleAlert, Wind, Volume2, VolumeX } from 'lucide-react';
import { Studio } from './studio';
import { useEngineSound } from './engine-audio';
import { sitePath } from './paths';
import type { CarId, ControlsState } from './studio';

const getCar=():CarId=>location.pathname.replace(/\/$/,'').split('/').pop()==='gt500'?'gt500':'rx7';
const initial:ControlsState={doorL:false,doorR:false,lights:false,hood:false,orbit:false,bright:false,aero:false,sound:false};

function DoorsIcon(){return <svg viewBox="0 0 24 24"><path d="M8 18V7l4-2 4 2v11M8 8 3 11v9l5-2m8-10 5 3v9l-5-2M10 18h4M5 14v2m14-2v2"/></svg>}
function LightsIcon(){return <svg viewBox="0 0 24 24"><path d="M12 6c-4 0-6 2.2-6 6s2 6 6 6V6ZM15 7h5m-5 3h6m-6 4h6m-6 3h5"/></svg>}
function HoodIcon(){return <svg viewBox="0 0 24 24"><path d="m4 12 4-7h8l4 7M4 12v7h16v-7M4 12l5-4h6l5 4M7 16h2m6 0h2"/></svg>}

class SceneBoundary extends React.Component<{children:React.ReactNode;onError:()=>void},{failed:boolean}>{
  state={failed:false};
  static getDerivedStateFromError(){return {failed:true};}
  componentDidCatch(error:Error){console.error('Unable to load the 3D studio',error);this.props.onError();}
  render(){return this.state.failed?null:this.props.children;}
}

export default function App(){
  const [car,setCar]=useState<CarId>(getCar),[controls,setControls]=useState(initial),[loaded,setLoaded]=useState(false),[failed,setFailed]=useState(false),[reset,setReset]=useState(0),[full,setFull]=useState(false);
  const main=useRef<HTMLElement>(null);
  const ready=useCallback(()=>setLoaded(true),[]);
  const error=useCallback(()=>setFailed(true),[]);
  const audioFailure=useCallback(()=>setControls(c=>({...c,sound:false})),[]);
  const {unlock,meter}=useEngineSound(car,controls.sound,controls.aero,audioFailure);
  useEffect(()=>{const pop=()=>{setCar(getCar());setControls(initial);setLoaded(false);setFailed(false);};window.addEventListener('popstate',pop);return()=>window.removeEventListener('popstate',pop);},[]);
  useEffect(()=>{document.title=car==='rx7'?'Mazda RX-7 · Garage':'Shelby GT500 · Garage';},[car]);
  useEffect(()=>{const change=()=>setFull(!!document.fullscreenElement);document.addEventListener('fullscreenchange',change);return()=>document.removeEventListener('fullscreenchange',change);},[]);
  const switchCar=(id:CarId)=>{if(id===car)return;history.pushState({},'',sitePath(`${id}/`));setLoaded(false);setFailed(false);setCar(id);setControls(initial);};
  const toggle=(key:keyof ControlsState)=>{
    const startsAudio=(key==='aero'&&!controls.aero)||(key==='sound'&&!controls.sound);
    const audioAvailable=!startsAudio||unlock();
    setControls(c=>key==='aero'?{...c,aero:!c.aero,sound:!c.aero&&audioAvailable}:key==='sound'?{...c,sound:!c.sound&&audioAvailable}:{...c,[key]:!c[key]});
  };
  const toggleDoors=()=>setControls(c=>{const open=!(c.doorL||c.doorR);return {...c,doorL:open,doorR:open};});
  const resetScene=()=>{setControls(initial);setReset(v=>v+1);};
  const fullscreen=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await main.current?.requestFullscreen?.();}catch{setFull(false);}};
  return <main ref={main} className={`garage ${car} ${loaded?'is-ready':''}`} aria-label={car==='rx7'?'Mazda RX-7 interactive studio':'Shelby GT500 interactive studio'} data-car={car}>
    <SceneBoundary onError={error}>
      {!failed&&<Canvas shadows dpr={[1,1.6]} camera={{position:[6,2.8,6.8],fov:32,near:.1,far:60}} gl={{antialias:true,alpha:false,powerPreference:'high-performance'}} onCreated={({gl})=>{gl.domElement.setAttribute('aria-label','3D car. Drag to rotate, pinch or scroll to zoom.');gl.domElement.setAttribute('role','img');gl.domElement.addEventListener('webglcontextlost',()=>{if(gl.domElement.isConnected)error();},{once:true});}}>
        <Suspense fallback={null}><Studio key={car} car={car} controls={controls} reset={reset} onReady={ready} onPartClick={toggle} onInteract={()=>setControls(c=>c.orbit?{...c,orbit:false}:c)}/></Suspense>
      </Canvas>}
    </SceneBoundary>
    <div className="vignette"/>
    <nav className="car-switch" aria-label="Choose car">
      {(['rx7','gt500'] as const).map(id=><a key={id} href={sitePath(`${id}/`)} aria-label={id==='rx7'?'View red Mazda RX-7':'View blue Shelby GT500'} aria-current={car===id?'page':undefined} className={`brand ${id}`} onClick={e=>{if(e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;e.preventDefault();switchCar(id);}}><img src={sitePath(`brands/${id==='rx7'?'mazda':'ford'}.svg`)} alt="" draggable={false}/></a>)}
    </nav>
    <div className="scene-tools">
      <button className="engine-sound icon-button" aria-label="Engine sound" aria-pressed={controls.sound} disabled={!loaded} onClick={()=>toggle('sound')}>{controls.sound?<Volume2/>:<VolumeX/>}<span ref={meter} className="audio-meter" data-level="0" aria-hidden="true"/></button>
      <button className="airflow icon-button" aria-label="Show airflow" aria-pressed={controls.aero} disabled={!loaded} onClick={()=>toggle('aero')}><Wind/></button>
      {document.fullscreenEnabled&&<button className="icon-button" aria-label={full?'Exit fullscreen':'Enter fullscreen'} onClick={fullscreen}>{full?<Minimize/>:<Maximize/>}</button>}
    </div>
    {(!loaded||failed)&&<div className="load-state" role="status" aria-label={failed?'The 3D scene could not load. Retry.':'Loading car'}>{failed?<button className="retry icon-button" onClick={()=>location.reload()} aria-label="Retry loading the car"><TriangleAlert/><RefreshCw/></button>:<span className="loader"/>}</div>}
    <div className="toolbar-wrap">
      <div className="toolbar" role="toolbar" aria-label="Car controls" aria-busy={!loaded}>
        <button className="icon-button" aria-label="Open doors" aria-pressed={controls.doorL||controls.doorR} disabled={!loaded} onClick={toggleDoors}><DoorsIcon/></button>
        <button className="icon-button" aria-label="Switch headlights" aria-pressed={controls.lights} disabled={!loaded} onClick={()=>toggle('lights')}><LightsIcon/></button>
        <button className="icon-button" aria-label="Open bonnet" aria-pressed={controls.hood} disabled={!loaded} onClick={()=>toggle('hood')}><HoodIcon/></button>
        <span className="separator"/>
        <button className="icon-button" aria-label="Rotate automatically" aria-pressed={controls.orbit} disabled={!loaded} onClick={()=>toggle('orbit')}><Orbit/></button>
        <button className="icon-button" aria-label="Change studio lighting" aria-pressed={controls.bright} disabled={!loaded} onClick={()=>toggle('bright')}>{controls.bright?<Sun/>:<Moon/>}</button>
        <button className="icon-button" aria-label="Reset view" disabled={!loaded} onClick={resetScene}><RotateCcw/></button>
      </div>
    </div>
    <a className="credits" href={sitePath('attribution.txt')} target="_blank" rel="noreferrer" aria-label="Model credits and licenses"><Info/></a>
  </main>;
}

