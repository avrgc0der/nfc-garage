import { useCallback, useEffect, useRef } from 'react';
import type { CarId } from './studio';

// Original procedural sound design, not recordings of either vehicle.
export function engineCycle(car:CarId,sampleRate:number){
  const rotary=car==='rx7',duration=rotary?.05:.1;
  const samples=new Float32Array(Math.round(sampleRate*duration));
  const pulses=rotary?[1,.94]:[1,.66,.92,.72,.86,.63,.98,.75];
  for(let i=0;i<samples.length;i++){
    const t=i/sampleRate;
    let pressure=0;
    for(let pulse=0;pulse<pulses.length;pulse++){
      const since=(t-pulse*duration/pulses.length+duration)%duration;
      for(let tail=0;tail<3;tail++){
        const age=since+tail*duration;
        const resonance=rotary?
          Math.sin(age*2*Math.PI*180)+.65*Math.sin(age*2*Math.PI*680)+.25*Math.sin(age*2*Math.PI*1340):
          Math.sin(age*2*Math.PI*85)+.55*Math.sin(age*2*Math.PI*170)+.18*Math.sin(age*2*Math.PI*520);
        pressure+=pulses[pulse]*Math.exp(-age*(rotary?105:75))*resonance;
      }
    }
    samples[i]=Math.tanh(pressure*1.7);
  }
  const mean=samples.reduce((sum,v)=>sum+v,0)/samples.length;
  let peak=0;
  for(let i=0;i<samples.length;i++){samples[i]-=mean;peak=Math.max(peak,Math.abs(samples[i]));}
  for(let i=0;i<samples.length;i++)samples[i]=samples[i]/peak*.7;
  return samples;
}

type Voice={exhaust:AudioBufferSourceNode;noise:AudioBufferSourceNode;whine:OscillatorNode;filter:BiquadFilterNode;noiseGain:GainNode;whineGain:GainNode;nodes:AudioNode[]};

class EngineAudio{
  readonly context:AudioContext;
  private master:GainNode;
  private analyser:AnalyserNode;
  private samples:Float32Array<ArrayBuffer>;
  private voice:Voice|null=null;
  private car:CarId;
  private enabled=false;
  private aero=false;
  private rpm=900;
  private timer:number;
  private startedAt=0;
  private suspendTimer:number|undefined;
  private onLevel:(level:number)=>void;

  constructor(car:CarId,onLevel:(level:number)=>void){
    this.car=car;this.onLevel=onLevel;
    this.context=new AudioContext();
    this.master=this.context.createGain();this.master.gain.value=0;
    const limiter=this.context.createDynamicsCompressor();
    limiter.threshold.value=-18;limiter.knee.value=18;limiter.ratio.value=5;limiter.attack.value=.004;limiter.release.value=.16;
    this.analyser=this.context.createAnalyser();this.analyser.fftSize=1024;
    this.samples=new Float32Array(this.analyser.fftSize);
    this.master.connect(limiter).connect(this.analyser).connect(this.context.destination);
    this.select(car);
    this.timer=window.setInterval(()=>this.update(),50);
  }

  select(car:CarId){
    if(this.voice&&car===this.car)return;
    if(this.voice){this.voice.exhaust.stop();this.voice.noise.stop();this.voice.whine.stop();this.voice.nodes.forEach(n=>n.disconnect());}
    this.car=car;this.rpm=car==='rx7'?1050:850;
    const ctx=this.context,rotary=car==='rx7';
    const cycle=engineCycle(car,ctx.sampleRate),buffer=ctx.createBuffer(1,cycle.length,ctx.sampleRate);buffer.copyToChannel(cycle,0);
    const exhaust=ctx.createBufferSource();exhaust.buffer=buffer;exhaust.loop=true;
    const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=rotary?1700:950;filter.Q.value=.65;
    exhaust.connect(filter).connect(this.master);
    const noiseBuffer=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate),data=noiseBuffer.getChannelData(0);
    let seed=rotary?17:43;
    for(let i=0;i<data.length;i++){seed=(seed*16807)%2147483647;data[i]=(seed/2147483647*2-1);}
    const noise=ctx.createBufferSource();noise.buffer=noiseBuffer;noise.loop=true;
    const noiseFilter=ctx.createBiquadFilter();noiseFilter.type='bandpass';noiseFilter.frequency.value=rotary?1700:650;noiseFilter.Q.value=.65;
    const noiseGain=ctx.createGain();noiseGain.gain.value=.015;
    noise.connect(noiseFilter).connect(noiseGain).connect(this.master);
    const whine=ctx.createOscillator();whine.type='sine';whine.frequency.value=rotary?1800:500;
    const whineGain=ctx.createGain();whineGain.gain.value=0;
    whine.connect(whineGain).connect(this.master);
    exhaust.start();noise.start();whine.start();
    this.voice={exhaust,filter,noise,noiseGain,whine,whineGain,nodes:[exhaust,filter,noise,noiseFilter,noiseGain,whine,whineGain]};
  }

  unlock(){clearTimeout(this.suspendTimer);return this.context.resume();}

  setMode(enabled:boolean,aero:boolean){
    if(enabled&&!this.enabled)this.startedAt=this.context.currentTime;
    this.enabled=enabled;this.aero=aero;
    clearTimeout(this.suspendTimer);
    const now=this.context.currentTime;
    this.master.gain.cancelScheduledValues(now);
    this.master.gain.setTargetAtTime(enabled?.27:0,now,enabled?.18:.07);
    if(!enabled){this.onLevel(0);this.suspendTimer=window.setTimeout(()=>{if(!this.enabled)void this.context.suspend();},450);}
  }

  private update(){
    if(!this.enabled||!this.voice||this.context.state!=='running')return;
    const ctx=this.context,rotary=this.car==='rx7',elapsed=ctx.currentTime-this.startedAt;
    const idle=rotary?1050:850,cruise=rotary?4400:3200;
    const breathe=this.aero?Math.sin(elapsed*.8)*220:Math.sin(elapsed*3)*22;
    const target=(this.aero?cruise:idle)+breathe;
    this.rpm+=(target-this.rpm)*(this.aero?.055:.12);
    this.voice.exhaust.playbackRate.setTargetAtTime(this.rpm/1200,ctx.currentTime,.08);
    this.voice.filter.frequency.setTargetAtTime((rotary?1200:700)+this.rpm*(rotary?.5:.35),ctx.currentTime,.1);
    this.voice.whine.frequency.setTargetAtTime(rotary?1800+this.rpm*.35:this.rpm*.37,ctx.currentTime,.1);
    this.voice.whineGain.gain.setTargetAtTime(this.aero?(rotary?.016:.065):.003,ctx.currentTime,.16);
    this.voice.noiseGain.gain.setTargetAtTime(this.aero?.06:.018,ctx.currentTime,.1);
    this.analyser.getFloatTimeDomainData(this.samples);
    const rms=Math.sqrt(this.samples.reduce((sum,s)=>sum+s*s,0)/this.samples.length);
    this.onLevel(Math.min(1,rms*4));
  }

  dispose(){clearInterval(this.timer);clearTimeout(this.suspendTimer);this.onLevel(0);void this.context.close();}
}

export function useEngineSound(car:CarId,enabled:boolean,aero:boolean,onFailure:()=>void){
  const engine=useRef<EngineAudio|null>(null),meter=useRef<HTMLSpanElement>(null);
  const level=useCallback((value:number)=>{
    if(meter.current){meter.current.style.setProperty('--level',String(value));meter.current.dataset.level=value.toFixed(3);}
  },[]);
  const unlock=useCallback(()=>{
    try{
      engine.current??=new EngineAudio(car,level);
      void engine.current.unlock().catch(onFailure);
      return true;
    }catch{onFailure();return false;}
  },[car,level,onFailure]);
  useEffect(()=>{engine.current?.select(car);},[car]);
  useEffect(()=>{
    const sync=()=>{
      if(!engine.current)return;
      engine.current.setMode(enabled&&!document.hidden,aero);
      if(enabled&&!document.hidden)void engine.current.unlock().catch(onFailure);
    };
    sync();document.addEventListener('visibilitychange',sync);
    return()=>document.removeEventListener('visibilitychange',sync);
  },[enabled,aero,onFailure]);
  useEffect(()=>()=>{engine.current?.dispose();engine.current=null;},[]);
  return {unlock,meter};
}
