import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import type { ThreeEvent } from '@react-three/fiber';
import { CameraControls, Environment, Lightformer, MeshReflectorMaterial, useGLTF } from '@react-three/drei';
import * as THREE from 'three';
import { Airflow } from './airflow';
import { sitePath } from './paths';

export type CarId='rx7'|'gt500';
export type CarPart='doorL'|'doorR'|'hood'|'lights';
export type ControlsState={doorL:boolean;doorR:boolean;lights:boolean;hood:boolean;orbit:boolean;bright:boolean;aero:boolean;sound:boolean};
type StudioProps={car:CarId;controls:ControlsState;reset:number;onReady:()=>void;onInteract:()=>void;onPartClick:(part:CarPart)=>void};

function hitPart(event:ThreeEvent<PointerEvent|MouseEvent>,car:CarId):CarPart|null{
  for(let object:THREE.Object3D|null=event.object;object;object=object.parent){
    if(object.name==='doorL'||object.name==='doorR'||object.name==='hood')return object.name;
    if(object.name==='lampL'||object.name==='lampR'||object.userData.part==='lights')return 'lights';
  }
  const mesh=event.object as THREE.Mesh;
  const material=Array.isArray(mesh.material)?mesh.material[event.face?.materialIndex??0]:mesh.material;
  // The Shelby combines its transparent headlight covers and windows in one mesh.
  if(car==='gt500'&&material?.name.includes('Window_Material')&&event.point.z>1.8&&event.point.y<.9&&Math.abs(event.point.x)>.43)return 'lights';
  return material&&['headlight','taillight','light-cluster'].includes(material.name)?'lights':null;
}

function floorTexture(){
  const canvas=document.createElement('canvas');canvas.width=canvas.height=256;
  const context=canvas.getContext('2d')!,pixels=context.createImageData(256,256);
  let seed=19;
  for(let i=0;i<pixels.data.length;i+=4){seed=(seed*16807)%2147483647;const v=125+(seed%26);pixels.data[i]=v;pixels.data[i+1]=v;pixels.data[i+2]=v;pixels.data[i+3]=255;}
  context.putImageData(pixels,0,0);
  for(let i=0;i<1600;i++){seed=(seed*16807)%2147483647;const x=seed%256;seed=(seed*16807)%2147483647;const y=seed%256;context.fillStyle=`rgba(35,38,41,${.02+(seed%8)/100})`;context.beginPath();context.ellipse(x,y,2+seed%20,1+seed%3,0,0,Math.PI*2);context.fill();}
  const texture=new THREE.CanvasTexture(canvas);texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.repeat.set(16,16);texture.colorSpace=THREE.SRGBColorSpace;return texture;
}

function EngineBay(){
  return <group position={[0,.52,1.27]}>
    <mesh position={[0,-.17,0]}><boxGeometry args={[1.1,.17,.9]}/><meshStandardMaterial color="#101216" roughness={.7}/></mesh>
    <mesh position={[0,-.03,0]}><boxGeometry args={[.46,.22,.46]}/><meshStandardMaterial color="#353c42" metalness={.75} roughness={.4}/></mesh>
    {Array.from({length:7},(_,i)=><mesh key={i} position={[-.19+i*.065,.085,0]}><boxGeometry args={[.018,.018,.41]}/><meshStandardMaterial color="#656a6d" metalness={.8} roughness={.32}/></mesh>)}
    {[-1,1].map(side=><group key={side}>
      <mesh position={[side*.48,.04,-.23]}><cylinderGeometry args={[.09,.115,.1,24]}/><meshStandardMaterial color="#23262a" metalness={.7} roughness={.4}/></mesh>
      <mesh position={[side*.31,.04,.03]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.12,.035,12,32,Math.PI]}/><meshStandardMaterial color="#303337" metalness={.4} roughness={.5}/></mesh>
    </group>)}
    <mesh position={[0,.12,-.23]} rotation={[0,0,Math.PI/2]}><cylinderGeometry args={[.018,.018,.96,12]}/><meshStandardMaterial color="#8b9195" metalness={.9} roughness={.24}/></mesh>
    <mesh position={[0,-.015,.4]}><boxGeometry args={[.78,.22,.075]}/><meshStandardMaterial color="#20262b" metalness={.7} roughness={.45}/></mesh>
    <mesh position={[.38,.05,.16]} rotation={[0,0,Math.PI/2]}><cylinderGeometry args={[.085,.085,.25,16]}/><meshStandardMaterial color="#9c9c98" metalness={.8} roughness={.25}/></mesh>
    <mesh position={[-.4,.04,-.14]}><boxGeometry args={[.2,.19,.3]}/><meshStandardMaterial color="#141619" roughness={.75}/></mesh>
  </group>;
}

function HeadlightBeams({car,on}:{car:CarId;on:boolean}){
  const refs=useRef<(THREE.SpotLight|null)[]>([]),tailRefs=useRef<(THREE.PointLight|null)[]>([]);
  const targets=useMemo(()=>[-1,1].map(side=>{const t=new THREE.Object3D();t.position.set(side*.8,.025,7);return t;}),[]);
  const smooth=useRef(0);
  useFrame((_,dt)=>{
    smooth.current=THREE.MathUtils.damp(smooth.current,on?1:0,6,dt);
    refs.current.forEach(l=>{if(l)l.intensity=smooth.current*38;});
    tailRefs.current.forEach(l=>{if(l)l.intensity=smooth.current*1.6;});
  });
  return <group>
    {[-1,1].map((side,i)=><group key={side}>
      <primitive object={targets[i]}/>
      <spotLight ref={r=>{refs.current[i]=r;}} position={[side*(car==='rx7'?.6:.7),.68,car==='rx7'?1.85:2.08]} target={targets[i]} color="#e5f2ff" intensity={0} angle={.32} penumbra={.65} distance={12} decay={1.2}/>
      <pointLight ref={r=>{tailRefs.current[i]=r;}} position={[side*.65,.56,car==='rx7'?-2:-2.3]} intensity={0} distance={2.3} decay={2} color="#ff0b16"/>
      {car==='gt500'&&<group userData={{part:'lights'}} position={[side*.73,.704,2.12]} rotation={[0,side*.28,0]}>
        {[-1,0,1].map(k=><mesh key={k} position={[k*.045,0,-Math.abs(k)*.008]} rotation={[0,0,-side*.32]}><boxGeometry args={[.012,.065,.007]}/><meshStandardMaterial color={on?'#e7f4ff':'#8c9da6'} emissive="#d9eeff" emissiveIntensity={on?6:0} toneMapped={false}/></mesh>)}
      </group>}
    </group>)}
  </group>;
}

function Car({car,controls,onReady,onPartClick}:{car:CarId;controls:ControlsState;onReady:()=>void;onPartClick:(part:CarPart)=>void}){
  const {scene}=useGLTF(sitePath(`models/${car}.glb?v=wheels`));
  const {gl}=useThree();
  const wheelSpeed=useRef(0),wheelAngle=useRef(0);
  const gesture=useRef({x:0,y:0,blocked:false,pointers:new Set<number>()});
  useEffect(()=>{
    const canvas=gl.domElement,g=gesture.current;
    const down=(event:PointerEvent)=>{g.pointers.add(event.pointerId);if(g.pointers.size===1){g.x=event.clientX;g.y=event.clientY;g.blocked=false;}else g.blocked=true;};
    const move=(event:PointerEvent)=>{if(g.pointers.has(event.pointerId)&&Math.hypot(event.clientX-g.x,event.clientY-g.y)>5)g.blocked=true;};
    const up=(event:PointerEvent)=>{g.pointers.delete(event.pointerId);};
    const cancel=(event:PointerEvent)=>{g.blocked=true;up(event);};
    const leave=()=>{canvas.style.cursor='grab';};
    canvas.style.cursor='grab';
    canvas.addEventListener('pointerdown',down,true);window.addEventListener('pointermove',move,true);window.addEventListener('pointerup',up,true);window.addEventListener('pointercancel',cancel,true);canvas.addEventListener('pointerleave',leave);
    return()=>{canvas.style.cursor='';g.pointers.clear();canvas.removeEventListener('pointerdown',down,true);window.removeEventListener('pointermove',move,true);window.removeEventListener('pointerup',up,true);window.removeEventListener('pointercancel',cancel,true);canvas.removeEventListener('pointerleave',leave);};
  },[gl]);
  const click=(event:ThreeEvent<MouseEvent>)=>{
    // Stop at the nearest surface: a door on the far side must not react through the body.
    event.stopPropagation();
    const part=hitPart(event,car);
    if(part&&event.button===0&&event.delta<=5&&!gesture.current.blocked)onPartClick(part);
  };
  const hover=(event:ThreeEvent<PointerEvent>)=>{
    event.stopPropagation();
    gl.domElement.style.cursor=event.buttons?'grabbing':hitPart(event,car)?'pointer':'grab';
  };
  const prepared=useMemo(()=>{
    const copy=scene.clone(true),materials=new Map<THREE.Material,THREE.Material>();
    copy.traverse(o=>{
      if(o instanceof THREE.Mesh){o.castShadow=true;o.receiveShadow=true;
        const clone=(m:THREE.Material)=>{if(!materials.has(m)){const c=m.clone() as THREE.MeshStandardMaterial;if(c.name==='light-cluster')c.emissiveMap=c.map;materials.set(m,c);}return materials.get(m)!;};
        o.material=Array.isArray(o.material)?o.material.map(clone):clone(o.material);
      }
    });
    const wheels=['FL','FR','BL','BR'].map(name=>({node:copy.getObjectByName('wheel'+name),axis:new THREE.Vector3(1,car==='gt500'?(name.endsWith('L')?.026:-.026):0,0).normalize()}));
    return {copy,wheels,materials:[...materials.values()] as THREE.MeshStandardMaterial[],doorL:copy.getObjectByName('doorL'),doorR:copy.getObjectByName('doorR'),hood:copy.getObjectByName('hood'),lampL:copy.getObjectByName('lampL'),lampR:copy.getObjectByName('lampR')};
  },[scene]);
  const reduced=useMemo(()=>matchMedia('(prefers-reduced-motion: reduce)').matches,[]);
  useEffect(()=>{onReady();return()=>prepared.materials.forEach(m=>m.dispose());},[prepared,onReady]);
  useFrame((_,dt)=>{
    const damp=(value:number,target:number)=>reduced?target:THREE.MathUtils.damp(value,target,5,dt);
    wheelSpeed.current=THREE.MathUtils.damp(wheelSpeed.current,controls.aero?16:0,controls.aero?1.6:4,Math.min(dt,.05));
    wheelAngle.current=(wheelAngle.current+wheelSpeed.current*Math.min(dt,.05))%(Math.PI*2);
    for(const wheel of prepared.wheels)wheel.node?.quaternion.setFromAxisAngle(wheel.axis,wheelAngle.current);
    if(prepared.doorL)prepared.doorL.rotation.y=damp(prepared.doorL.rotation.y,controls.doorL?-1.06:0);
    if(prepared.doorR)prepared.doorR.rotation.y=damp(prepared.doorR.rotation.y,controls.doorR?1.06:0);
    if(prepared.hood)prepared.hood.rotation.x=damp(prepared.hood.rotation.x,controls.hood?-1.05:0);
    for(const lamp of [prepared.lampL,prepared.lampR])if(lamp)lamp.rotation.x=damp(lamp.rotation.x,controls.lights?0:.60);
    for(const m of prepared.materials){
      if(m.name==='headlight'){m.emissive.set('#cde7ff');m.emissiveIntensity=damp(m.emissiveIntensity,controls.lights?3.5:0);}
      if(m.name==='taillight'){m.emissive.set('#ff0312');m.emissiveIntensity=damp(m.emissiveIntensity,controls.lights?1.7:0);}
      if(m.name==='light-cluster'){m.emissive.set('#edf5ff');m.emissiveIntensity=damp(m.emissiveIntensity,controls.lights?1.6:0);}
    }
  });
  return <group position={[0,.012,0]} onClick={click} onPointerMove={hover} onPointerOut={()=>{gl.domElement.style.cursor='grab';}}><primitive object={prepared.copy}/>{car==='rx7'&&<EngineBay/>}<HeadlightBeams car={car} on={controls.lights}/></group>;
}

function Room({accent,bright}:{accent:string;bright:boolean}){
  const texture=useMemo(floorTexture,[]),ambient=useRef<THREE.AmbientLight>(null),key=useRef<THREE.DirectionalLight>(null);
  useEffect(()=>()=>texture.dispose(),[texture]);
  useFrame((_,dt)=>{if(ambient.current)ambient.current.intensity=THREE.MathUtils.damp(ambient.current.intensity,bright?.8:.25,4,dt);if(key.current)key.current.intensity=THREE.MathUtils.damp(key.current.intensity,bright?3.5:2.2,4,dt);});
  return <>
    <color attach="background" args={['#0b0c0f']}/><fog attach="fog" args={['#0b0c0f',17,34]}/>
    <ambientLight ref={ambient} intensity={.25}/>
    <directionalLight ref={key} position={[3,7,2]} intensity={2.2} color="#f1f2ef" castShadow shadow-mapSize={[2048,2048]} shadow-camera-left={-5} shadow-camera-right={5} shadow-camera-top={5} shadow-camera-bottom={-5} shadow-bias={-.00015} shadow-normalBias={.02}/>
    <spotLight position={[-4,4,-3]} intensity={80} angle={.8} penumbra={1} color={accent} distance={12}/>
    <pointLight position={[-7,.5,-10]} intensity={22} color={accent} distance={7} decay={1.4}/>
    <pointLight position={[5,.5,-12]} intensity={15} color={accent} distance={6} decay={1.4}/>
    <rectAreaLight position={[0,4,-4]} rotation={[Math.PI/5,Math.PI,0]} width={7} height={2} intensity={5} color="#c7d3e8"/>
    <Environment resolution={256} frames={1}>
      <Lightformer form="rect" intensity={5} position={[0,5,0]} rotation={[Math.PI/2,0,0]} scale={[5,3,1]}/>
      <Lightformer form="rect" intensity={3} position={[-5,2,1]} rotation={[0,Math.PI/2,0]} scale={[7,1.5,1]}/>
      <Lightformer form="rect" intensity={3} position={[5,2,-1]} rotation={[0,-Math.PI/2,0]} scale={[7,2,1]}/>
      <Lightformer form="rect" intensity={1.2} color={accent} position={[0,1,-5]} scale={[8,1,1]}/>
    </Environment>
    <mesh rotation={[-Math.PI/2,0,0]} receiveShadow>
      <planeGeometry args={[70,70]}/>
      <MeshReflectorMaterial resolution={768} blur={[160,50]} mixBlur={1} mixStrength={18} mirror={.9} color="#121315" metalness={.35} roughness={.65} envMapIntensity={.22} map={texture} bumpMap={texture} bumpScale={.025} depthScale={.6} minDepthThreshold={.4} maxDepthThreshold={1.4}/>
    </mesh>
    <mesh position={[0,4,0]}><cylinderGeometry args={[15,15,8,96,1,true]}/><meshStandardMaterial color="#292b2e" roughness={.94} map={texture} bumpMap={texture} bumpScale={.08} side={THREE.BackSide}/></mesh>
    <mesh position={[0,.25,0]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[14.95,.014,6,160]}/><meshBasicMaterial color="#c2b8a8" toneMapped={false}/></mesh>
    {Array.from({length:40},(_,i)=>{const a=i*Math.PI/20;return <mesh key={i} position={[Math.sin(a)*14.94,3.8,Math.cos(a)*14.94]} rotation={[0,a,0]}><boxGeometry args={[.018,7.6,.018]}/><meshStandardMaterial color="#090a0b" roughness={1}/></mesh>;})}
    <group position={[0,2.8,-3.5]}>
      <mesh><boxGeometry args={[5.4,.07,2.8]}/><meshStandardMaterial color="#121417" roughness={.6}/></mesh>
      <mesh position={[0,-.042,0]} rotation={[Math.PI/2,0,0]}><planeGeometry args={[5.15,2.55]}/><meshBasicMaterial color="#e9eeef" toneMapped={false}/></mesh>
    </group>
  </>;
}

export function Studio({car,controls,reset,onReady,onInteract,onPartClick}:StudioProps){
  const camera=useRef<CameraControls>(null),{size,setFrameloop,camera:sceneCamera}=useThree();
  const aspect=size.width/size.height;
  useEffect(()=>{
    const c=camera.current;if(!c)return;
    const portrait=aspect<.9;
    const perspective=sceneCamera as THREE.PerspectiveCamera;
    perspective.fov=portrait?50:32;perspective.updateProjectionMatrix();
    const fit=Math.max(1,(portrait?1.35:1.5)/aspect)*(portrait?Math.tan(16*Math.PI/180)/Math.tan(25*Math.PI/180):1);
    c.setLookAt(4.2*fit,.65+.9*fit,4.6*fit,0,.65,0,false);
  },[aspect,reset,car,sceneCamera]);
  useEffect(()=>{const visible=()=>setFrameloop(document.hidden?'never':'always');document.addEventListener('visibilitychange',visible);return()=>document.removeEventListener('visibilitychange',visible);},[setFrameloop]);
  useFrame((_,dt)=>{if(controls.orbit)camera.current?.rotate(dt*.16,0,false);});
  return <>
    <Room accent={car==='rx7'?'#d62532':'#1f6fd6'} bright={controls.bright}/>
    <Car car={car} controls={controls} onReady={onReady} onPartClick={onPartClick}/>
    <Airflow car={car} controls={controls}/>
    <CameraControls ref={camera} makeDefault minDistance={3.6} maxDistance={32} minPolarAngle={.2} maxPolarAngle={Math.PI/2-.045} dollySpeed={.65} truckSpeed={.6} smoothTime={.18} draggingSmoothTime={.12} onControlStart={onInteract}/>
  </>;
}
