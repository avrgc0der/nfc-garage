/// <reference types="vite/client" />

// Vite supplies the deployment prefix for both root and project Pages hosting.
export const sitePath = (path: string) => `${import.meta.env.BASE_URL}${path.replace(/^\//, '')}`;
