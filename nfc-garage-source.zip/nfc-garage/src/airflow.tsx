import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { CarId, ControlsState } from './studio';

// Art-directed streamlines, not a computed fluid simulation. Front is +Z.
function makeFlow(car:CarId,hood:boolean,doorL:boolean,doorR:boolean){
  const length=car==='rx7'?1:1.1,roof=car==='rx7'?1.29:1.43,nose=car==='rx7'?.93:1.07;
  const curves:{points:THREE.Vector3[];wake:boolean}[]=[];
  const line=(points:number[][],wake=false)=>curves.push({points:points.map(([x,y,z])=>new THREE.Vector3(x,y,z*length)),wake});
  for(let lane=-4;lane<=4;lane++){
    const x=lane*.195,edge=Math.abs(lane)/4;
    for(let layer=0;layer<2;layer++){
      const lift=layer*.11,hoodLift=hood?.85:0;
      line([[x,.72+lift,4.2],[x,.82+lift,2.7],[x,nose+lift+hoodLift,1.8],
        [x*.94,roof+.06+lift+hoodLift*.3,.42],[x*.94,roof+.1+lift,-.45],
        [x*1.07,1.17+lift+edge*.12,-1.65],[x*1.22,1.04+lift,-2.4],
        [x*1.32,.85+lift,-3.6],[x*1.45,.8+lift,-4.8]]);
    }
  }
  for(const side of [-1,1]){
    const doorOpen=side===1?doorL:doorR;
    for(let layer=0;layer<3;layer++){
      const y=.34+layer*.23,spread=doorOpen?.55:0;
      line([[side*.83,y,4.3],[side*.88,y,2.65],[side*1.04,y,1.55],
        [side*(1.12+spread),y+.06,.2],[side*(1.12+spread),y+.07,-.9],
        [side*1.11,y+.1,-2.2],[side*1.19,y+.06,-3.3],[side*1.33,y,-4.7]]);
    }
    const points=Array.from({length:34},(_,i)=>{
      const t=i/33,a=t*Math.PI*3.3,r=.025+t*.18;
      return [side*(.82+t*.55)+Math.cos(a)*r,.87+Math.sin(a)*r,-2.1-t*2.7];
    });
    line(points,true);
  }
  const tubes=curves.map(({points,wake},i)=>{
    const tube=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),120,wake?.008:.006,5,false);
    const n=tube.attributes.position.count;
    tube.setAttribute('flowSeed',new THREE.Float32BufferAttribute(new Float32Array(n).fill((i*.137)%1),1));
    tube.setAttribute('isWake',new THREE.Float32BufferAttribute(new Float32Array(n).fill(wake?1:0),1));
    return tube;
  });
  const merged=mergeGeometries(tubes)!;tubes.forEach(t=>t.dispose());return merged;
}

export function Airflow({car,controls}:{car:CarId;controls:ControlsState}){
  const mesh=useRef<THREE.Mesh>(null);
  const geometry=useMemo(()=>makeFlow(car,controls.hood,controls.doorL,controls.doorR),[car,controls.hood,controls.doorL,controls.doorR]);
  const reduced=useMemo(()=>matchMedia('(prefers-reduced-motion: reduce)').matches,[]);
  const material=useMemo(()=>new THREE.ShaderMaterial({
    transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,toneMapped:false,
    uniforms:{uTime:{value:0},uVisibility:{value:0}},
    vertexShader:`attribute float flowSeed;attribute float isWake;
      varying vec2 vUv;varying float vSeed;varying float vWake;
      void main(){vUv=uv;vSeed=flowSeed;vWake=isWake;
        gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader:`uniform float uTime;uniform float uVisibility;
      varying vec2 vUv;varying float vSeed;varying float vWake;
      void main(){
        float p=fract(vUv.x*2.4-uTime*.55+vSeed);
        float trail=smoothstep(.0,.24,p)*(1.-smoothstep(.24,.29,p));
        float edge=smoothstep(.0,.13,vUv.x)*(1.-smoothstep(.83,1.,vUv.x));
        vec3 cool=mix(vec3(.14,.58,.8),vec3(.67,.91,1.),trail);
        vec3 color=mix(cool,vec3(.95,.41,.16),vWake*.8);
        gl_FragColor=vec4(color,(.13+trail*.77)*edge*uVisibility);
        #include <colorspace_fragment>
      }`,
  }),[]);
  useEffect(()=>()=>geometry.dispose(),[geometry]);
  useEffect(()=>()=>material.dispose(),[material]);
  useFrame((_,dt)=>{
    const u=material.uniforms;
    u.uVisibility.value=reduced?(controls.aero?1:0):THREE.MathUtils.damp(u.uVisibility.value,controls.aero?1:0,5,dt);
    if(controls.aero&&!reduced)u.uTime.value+=Math.min(dt,.05);
    if(mesh.current)mesh.current.visible=u.uVisibility.value>.005;
  });
  return <mesh ref={mesh} geometry={geometry} material={material} raycast={()=>{}} visible={false} dispose={null}/>;
}
