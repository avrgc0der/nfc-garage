import fs from 'node:fs';
for(const route of ['rx7','gt500']){
  fs.mkdirSync(`dist/${route}`,{recursive:true});
  fs.copyFileSync('dist/index.html',`dist/${route}/index.html`);
}

// Serve the Vite build directly when deployed from a GitHub Pages branch.
fs.writeFileSync('dist/.nojekyll','');
