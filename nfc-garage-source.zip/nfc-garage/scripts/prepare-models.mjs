import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS, KHRMaterialsClearcoat } from '@gltf-transform/extensions';
import { compactPrimitive, transformPrimitive, dedup, weld, prune, simplify, meshopt } from '@gltf-transform/functions';
import { MeshoptEncoder, MeshoptSimplifier } from 'meshoptimizer';
import { components } from './inspect-models.mjs';
import fs from 'node:fs';

await Promise.all([MeshoptEncoder.ready, MeshoptSimplifier.ready]);
const io=new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({'meshopt.encoder':MeshoptEncoder});
const identity=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];

// Clip continuous body surfaces along clean panel boundaries, interpolating normals.
function splitPolygon(poly,plane){
  const inside=[],outside=[];
  const distance=v=>plane[0]*v[0]+plane[1]*v[1]+plane[2]*v[2]+plane[3];
  for(let i=0;i<poly.length;i++){
    const a=poly[i],b=poly[(i+1)%poly.length],da=distance(a),db=distance(b);
    (da>=0?inside:outside).push(a);
    if((da>=0)!==(db>=0)){const t=da/(da-db),v=a.map((x,j)=>x+(b[j]-x)*t);inside.push(v);outside.push(v);}
  }
  return [inside,outside];
}
function extract(poly,planes){let current=poly,rest=[];for(const plane of planes){const [inside,outside]=splitPolygon(current,plane);if(outside.length>=3)rest.push(outside);current=inside;if(current.length<3)break;}return [current.length>=3?[current]:[],rest];}

for(const car of ['rx7','gt500']){
  const doc=await io.read(`assets/source/${car}.glb`),root=doc.getRoot(),originalNodes=[...root.listNodes()];
  const scale=car==='rx7'?.282:100;
  const projectorMaterial=car==='gt500'?doc.createMaterial('headlight').setBaseColorFactor([.7,.82,.9,1]).setMetallicFactor(.1).setRoughnessFactor(.1):null;
  const hinges=car==='rx7'?{doorL:[.72,.75,.46],doorR:[-.72,.75,.46],hood:[0,.80,.86],lampL:[.61,.70,1.59],lampR:[-.61,.70,1.59]}:{doorL:[.79,.85,.735],doorR:[-.79,.85,.735],hood:[0,.94,.758]};
  for(const side of ['L','R'])for(const end of ['F','B']){
    const sign=side==='L'?1:-1;
    hinges['wheel'+end+side]=car==='rx7'?[sign*.72,.3245,end==='F'?1.2975:-1.1095]:[sign*.81,.347,end==='F'?1.429:-1.29];
  }
  const buckets=new Map();
  function append(group,mat,semantics,vertices){
    const key=group+'|'+root.listMaterials().indexOf(mat)+'|'+semantics.join(',');
    if(!buckets.has(key))buckets.set(key,{group,mat,semantics,data:semantics.map(()=>[])});
    const b=buckets.get(key),pivot=hinges[group]??[0,0,0];
    for(let t=1;t<vertices.length-1;t++)for(const v of [vertices[0],vertices[t],vertices[t+1]]){
      let offset=0;
      for(let j=0;j<semantics.length;j++){
        const size=semantics[j]==='TEXCOORD_0'?2:3;
        for(let k=0;k<size;k++)b.data[j].push(v[offset+k]-(j===0?pivot[k]:0));
        offset+=size;
      }
    }
  }
  function classify(name,c){
    const {min:mi,max:ma}=c,cx=(mi[0]+ma[0])/2,side=cx>0?'L':'R';
    const wheel=car==='rx7'?/^(Tir\d|Disk_wheel|Wheel_have|brakedisk)/.test(name):/Wheel1A/.test(name);
    if(wheel)return 'wheel'+(mi[2]+ma[2]>0?'F':'B')+side;
    if(car==='rx7'){
      if(/Headligyt|Headlights_lead|Headlight_base|Headlight_mirror/.test(name))return 'lamp'+side;
      if(/^(Door_|Dook_|Glass_door|Door_Rubber|Window_triangle|Mirror_base|Mirror01)/.test(name))return 'door'+side;
      return 'body';
    }
    const atSide=Math.min(Math.abs(mi[0]),Math.abs(ma[0]))>.54&&mi[0]*ma[0]>0;
    if(atSide&&mi[2]>-.705&&ma[2]<.749&&mi[1]>.22&&ma[1]<1.29)return 'door'+side;
    if(mi[2]>.749&&ma[2]<2.25&&mi[1]>.685&&ma[1]<1.02&&mi[0]>-.85&&ma[0]<.85&&!/Engine|Light|Window|Grille[2456]/.test(name))return 'hood';
    return 'body';
  }
  for(const node of originalNodes){
    const name=node.getName();
    for(const source of node.getMesh()?.listPrimitives()??[]){
      const p=source.clone();compactPrimitive(p);
      const matrix=node.getWorldMatrix().map((v,i)=>i<12?v*scale:i<15?v*scale:v);
      transformPrimitive(p,matrix);
      // The downloaded car has static bind-pose geometry; no skinning is needed.
      const semantics=['POSITION','NORMAL',...(p.getAttribute('TEXCOORD_0')?['TEXCOORD_0']:[])];
      const arrays=semantics.map(s=>p.getAttribute(s)?.getArray());
      const vertex=i=>semantics.flatMap((s,j)=>{const n=s==='TEXCOORD_0'?2:3;return Array.from(arrays[j]?.slice(i*n,i*n+n)??[0,1,0]);});
      const baseMaterial=p.getMaterial();
      for(const c of components(p,identity)){
        const projector=projectorMaterial&&/Light_Geo/.test(name)&&c.min[2]>1.92&&c.max[2]<1.96&&c.min[1]>.63&&c.max[0]-c.min[0]<.09;
        const material=projector?projectorMaterial:baseMaterial;
        const group=classify(name,c);
        for(let i=0;i<c.indices.length;i+=3){
          const tri=c.indices.slice(i,i+3).map(vertex);
          if(car==='rx7'&&(name==='Body01'||name==='Salon01')){
            let rest=[tri];
            for(const side of [1,-1]){
              const planes=[[side,0,0,-.60],[0,1,0,-.24],[0,-1,0,.89],[0,.25,1,.48],[0,-.04,-1,.50]];
              let remaining=[];
              for(const poly of rest){const [cut,out]=extract(poly,planes);for(const v of cut)append(side>0?'doorL':'doorR',material,semantics,v);remaining.push(...out);}rest=remaining;
            }
            for(const poly of rest){
              if(name==='Body01'){
                const [cut,out]=extract(poly,[[0,1,0,-.55],[0,0,1,-.86],[0,0,-1,1.95],[1,0,-.22,.85],[-1,0,-.22,.85]]);
                for(const v of cut)append('hood',material,semantics,v);
                for(const v of out)append('body',material,semantics,v);
              }else append('body',material,semantics,poly);
            }
          }else append(group,material,semantics,tri);
        }
      }
      p.dispose();
    }
  }
  for(const n of originalNodes)n.dispose();
  for(const s of [...root.listScenes()])s.dispose();
  const scene=doc.createScene(car),buffer=doc.createBuffer();root.setDefaultScene(scene);
  const groups=new Map();
  for(const b of buckets.values()){
    if(!groups.has(b.group)){const n=doc.createNode(b.group).setTranslation(hinges[b.group]??[0,0,0]);scene.addChild(n);groups.set(b.group,n);}
    const prim=doc.createPrimitive().setMaterial(b.mat);
    b.semantics.forEach((semantic,i)=>prim.setAttribute(semantic,doc.createAccessor().setType(semantic==='TEXCOORD_0'?'VEC2':'VEC3').setArray(new Float32Array(b.data[i])).setBuffer(buffer)));
    let mesh=groups.get(b.group).getMesh();if(!mesh){mesh=doc.createMesh(b.group);groups.get(b.group).setMesh(mesh);}mesh.addPrimitive(prim);
  }
  const cc=doc.createExtension(KHRMaterialsClearcoat);
  for(const mat of root.listMaterials()){
    const name=mat.getName();
    if((car==='rx7'&&name==='Material')||(car==='gt500'&&/Paint_Material/.test(name))){
      mat.setName('paint').setBaseColorFactor(car==='rx7'?[.48,.006,.012,1]:[.006,.09,.43,1]).setMetallicFactor(.45).setRoughnessFactor(.24).setExtension('KHR_materials_clearcoat',cc.createClearcoat().setClearcoatFactor(1).setClearcoatRoughnessFactor(.12));
    }
    if(car==='rx7'){
      if(name==='Material.004')mat.setName('glass').setBaseColorFactor([.035,.055,.068,.38]).setAlphaMode('BLEND').setMetallicFactor(.25).setRoughnessFactor(.12).setExtension('KHR_materials_transmission',null);
      if(name==='Material.005')mat.setName('rubber').setBaseColorFactor([.012,.014,.017,1]).setMetallicFactor(0).setRoughnessFactor(.84);
      if(name==='Material.007'||name==='Material.009')mat.setMetallicFactor(.9).setRoughnessFactor(.22);
      if(name==='Material.002')mat.setName('headlight').setBaseColorFactor([.65,.78,.88,1]).setMetallicFactor(.2).setRoughnessFactor(.1);
      if(name==='redglass')mat.setName('taillight').setBaseColorFactor([.25,.001,.003,1]).setRoughnessFactor(.18).setAlphaMode('OPAQUE').setExtension('KHR_materials_transmission',null);
    }else{
      if(name==='red_glass')mat.setName('taillight').setBaseColorFactor([.35,.001,.002,1]).setAlphaMode('OPAQUE').setRoughnessFactor(.22).setExtension('KHR_materials_transmission',null);
      if(name.includes('Window_Material'))mat.setBaseColorFactor([.025,.038,.05,.36]).setAlphaMode('BLEND').setRoughnessFactor(.1).setMetallicFactor(.25).setExtension('KHR_materials_transmission',null);
      if(name.includes('LightA_Material'))mat.setName('light-cluster');
    }
    if(car==='rx7')mat.setDoubleSided(true);
  }
  await doc.transform(prune(),dedup(),weld(),simplify({simplifier:MeshoptSimplifier,ratio:car==='rx7'?.48:.82,error:.0002}),prune(),meshopt({encoder:MeshoptEncoder,level:'medium',quantizePosition:16,quantizeNormal:12}));
  // Quantization recenters mesh nodes. Put mechanical pivots above those transforms.
  for(const [name,pivot] of Object.entries(hinges)){
    const meshNode=groups.get(name);if(!meshNode)continue;
    meshNode.setName(name+'_mesh');scene.removeChild(meshNode);
    meshNode.setTranslation(meshNode.getTranslation().map((v,i)=>v-pivot[i]));
    scene.addChild(doc.createNode(name).setTranslation(pivot).addChild(meshNode));
  }
  await io.write(`public/models/${car}.glb`,doc);
  console.log(car, [...groups.keys()],(fs.statSync(`public/models/${car}.glb`).size/1024/1024).toFixed(2)+' MB');
}
