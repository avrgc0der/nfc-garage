import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import fs from 'node:fs';

export function components(prim, matrix, weld = true) {
  const pos = prim.getAttribute('POSITION'), a = pos.getArray(), n = pos.getCount();
  const idx = prim.getIndices()?.getArray() ?? Uint32Array.from({ length:n }, (_,i)=>i);
  const parent = Int32Array.from({length:n},(_,i)=>i), keys = new Map();
  const find = i => { while(parent[i]!==i) {parent[i]=parent[parent[i]];i=parent[i];} return i; };
  const union=(a,b)=>{parent[find(a)]=find(b);};
  for(let i=0;weld && i<n;i++){const k=[0,1,2].map(j=>Math.round(a[i*3+j]*1e5)).join(',');if(keys.has(k))union(i,keys.get(k));else keys.set(k,i);}
  for(let i=0;i<idx.length;i+=3){union(idx[i],idx[i+1]);union(idx[i+1],idx[i+2]);}
  const sets=new Map();
  for(let i=0;i<idx.length;i+=3){const key=find(idx[i]);if(!sets.has(key))sets.set(key,[]);sets.get(key).push(idx[i],idx[i+1],idx[i+2]);}
  return [...sets.values()].map(indices=>{
    const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
    for(const i of indices){const x=a[i*3],y=a[i*3+1],z=a[i*3+2];const v=[matrix[0]*x+matrix[4]*y+matrix[8]*z+matrix[12],matrix[1]*x+matrix[5]*y+matrix[9]*z+matrix[13],matrix[2]*x+matrix[6]*y+matrix[10]*z+matrix[14]];v.forEach((val,j)=>{min[j]=Math.min(min[j],val);max[j]=Math.max(max[j],val);});}
    return {indices,triangles:indices.length/3,min,max};
  }).sort((a,b)=>b.triangles-a.triangles);
}
if(process.argv[1].endsWith('inspect-models.mjs')){
  const io=new NodeIO().registerExtensions(ALL_EXTENSIONS);
  for(const car of ['rx7','gt500']){
    const doc=await io.read(`assets/source/${car}.glb`), list=[];
    for(const node of doc.getRoot().listNodes()) for(const p of node.getMesh()?.listPrimitives()??[]) {
      const cs=components(p,node.getWorldMatrix());
      list.push({name:node.getName(),material:p.getMaterial()?.getName(),components:cs.map(({indices,...c})=>c)});
    }
    fs.writeFileSync(`assets/source/${car}-components.json`,JSON.stringify(list,null,2));
    console.log(car,JSON.stringify(list.filter(l=>/Body01|Paint_Geo|Glass_door|Window_Geo|Interior_Geo|Base_Geo/.test(l.name)).map(l=>({...l,components:l.components.slice(0,22)})),null,2));
  }
}
